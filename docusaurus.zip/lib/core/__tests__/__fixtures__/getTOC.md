## foo

### foo

### foo 1

## foo 1

## foo 2

### foo

#### 4th level headings

All 4th level headings should not be shown by default

## bar

### bar

#### bar

4th level heading should be ignored by default, but is should be always taken into account, when generating slugs

### `bar`

#### `bar`

## bar

### bar

#### bar

## bar
