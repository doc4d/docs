---
id: doc3
title: Document 3
---

Test subdirectory file

### Replace this

- [doc3](subdir/doc3.md)
