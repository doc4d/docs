---
title: Docusaurus
author: Endilie
authorURL: https://github.com/endiliey
authorFBID: 100000251103620
authorTwitter: endiliey
---

![Docusaurus](/img/slash-introducing.png)

We are very happy to introduce [Docusaurus](https://github.com/facebook/docusaurus) to help you manage one or many open source websites.
