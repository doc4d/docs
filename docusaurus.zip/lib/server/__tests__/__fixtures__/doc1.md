---
id: doc1
title: Document 1
---

Docusaurus is the best :)

![image1](assets/image1.png)

```js
console.log('Docusaurus');
```

![image2](assets/image2.jpg)

![image3](assets/image3.gif)

Don't replace the one below

```md
![image4](assets/image4.bmp)
```
