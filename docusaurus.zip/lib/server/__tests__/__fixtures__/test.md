---
title: This is not a css
---

This is a markdown, not a css

.homeWrapperInner .homeCodeSnippet > div:nth-child(1) { display: none; }

@media (max-width: 480px) { .projectTitle { font-size: 30px; }

.homeCodeSnippet .hljs { font-size: 13px; padding: 0; } .homeWrapperInner .homeCodeSnippet > div:nth-child(1) { display: block; } .homeWrapperInner .homeCodeSnippet > div:nth-child(2) { display: none; } }
